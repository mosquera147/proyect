# GESTOR HOSPITALARIO

## Log in as admin/doctor
Username: admin@admin.com

Password: admin123

## Enter as pacient
Username: user@user.com

Password: user123
