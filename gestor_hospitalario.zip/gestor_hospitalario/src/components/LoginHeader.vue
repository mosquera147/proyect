<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary align-center">
      <a class="navbar-brand mx-auto" style="color: white">SISTEMA USC</a>
    </nav>
  </div>
</template>
